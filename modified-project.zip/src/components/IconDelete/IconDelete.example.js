import IconDelete from './IconDelete';

export const Icon = {
  component: IconDelete,
  props: {},
  group: 'icons',
};
