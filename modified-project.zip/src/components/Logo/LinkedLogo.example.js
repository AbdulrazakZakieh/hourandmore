import LinkedLogo from './LinkedLogo';

export const LinkedLogo_desktop = {
  component: LinkedLogo,
  props: {
    layout: 'desktop',
  },
  group: 'logo',
};
