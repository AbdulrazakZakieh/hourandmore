import IconKeys from './IconKeys';

export const Icon = {
  component: IconKeys,
  props: {},
  group: 'icons',
};
