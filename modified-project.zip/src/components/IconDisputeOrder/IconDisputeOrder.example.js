import IconDisputeOrder from './IconDisputeOrder';

export const Icon = {
  component: IconDisputeOrder,
  props: {},
  group: 'icons',
};
