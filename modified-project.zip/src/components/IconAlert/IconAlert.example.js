import IconAlert from './IconAlert';

export const Icon = {
  component: IconAlert,
  props: {},
  group: 'icons',
};
