import IconInquiry from './IconInquiry';

export const Icon = {
  component: IconInquiry,
  props: {},
  group: 'icons',
};
